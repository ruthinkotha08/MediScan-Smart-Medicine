# MediScan — Smart Medicine Verification Prototype

## What this prototype demonstrates
1. QR scanning using a browser camera.
2. Product/batch lookup from a sample local database.
3. Manufacturing date and expiry date display.
4. Automatic expired/valid status.
5. Manufacturer, batch, ingredient and dosage-form display.
6. Simple-language medicine explanation placeholder.
7. Safety warning section.
8. "My Medicines" cabinet using browser localStorage.

## Demo QR values
Create QR codes containing exactly:
- MED001
- MED002
- MED003

MED003 is intentionally expired so the judges can see the safety detection.

## Run
Because browser camera access generally requires a secure context, use a local web server.

Example:
python -m http.server 8000

Then open:
http://localhost:8000

## Important
The included medicine records are fictional demo data. For a real product, medicine information must come from authoritative pharmaceutical/product data sources and must be validated before use.

## Suggested next development
- Python FastAPI backend
- PostgreSQL/Azure SQL database
- Admin portal for product and batch records
- QR generation for registered batches
- Azure AI / Azure OpenAI for plain-language explanations
- User authentication
- Notifications for medicines approaching expiry
- Audit trail and tamper-resistant batch verification
